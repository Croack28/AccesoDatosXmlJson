package unidad1;

import java.io.Serializable;

public class Contacto implements Comparable<Contacto> , Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3289784827046841063L;
	protected String nombre;
	protected String teléfono;
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTeléfono() {
		return teléfono;
	}
	public void setTeléfono(String teléfono) {
		this.teléfono = teléfono;
	}
	public Contacto(String nombre, String teléfono) {
		super();
		this.nombre = nombre;
		this.teléfono = teléfono;
	}
	@Override
	public String toString() {
		return "Contacto [nombre=" + nombre + ", teléfono=" + teléfono + "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contacto other = (Contacto) obj;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		return true;
	}
	@Override
	public int compareTo(Contacto c) {
		return nombre.compareTo(c.nombre);
	}
	
	public static Contacto contactoFromCSV(String línea) {
		String[] data = línea.split(",");
		if (data.length!=2) {
			//System.err.println("Línea errónea, no contiene contacto: " + línea);
			return null;
		}
		return(new Contacto(data[0],data[1]));
	} // contactoFromCSV
	
} // class Contacto
