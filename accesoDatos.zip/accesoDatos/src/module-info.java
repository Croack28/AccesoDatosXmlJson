/**
 * 
 */
/**
 * 
 */
module accesoDatos {
	requires xstream;
	requires java.xml;
	opens xmlJson to xstream;
	exports xmlJson;
	opens transparencias to xstream;
	exports transparencias;
}