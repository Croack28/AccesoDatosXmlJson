package xmlJson;

import java.io.File;
import java.util.Iterator;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import com.thoughtworks.xstream.persistence.XmlArrayList;
import com.thoughtworks.xstream.security.AnyTypePermission;
import com.thoughtworks.xstream.persistence.FilePersistenceStrategy;
import com.thoughtworks.xstream.persistence.PersistenceStrategy;

public class XmlPersistenetLeer {
    
    protected static String fichero = "xmlPersistente";

    public static void main(String[] args) {
        
        // Configurar XStream con permisos de seguridad antes de la persistencia
        XStream xstream = new XStream(new StaxDriver());
        xstream.addPermission(AnyTypePermission.ANY);  // Permitir todas las clases (solo para desarrollo)

        // Asignar el XStream configurado a la estrategia de persistencia
        PersistenceStrategy strategy = new FilePersistenceStrategy(new File(fichero), xstream);
        XmlArrayList lista = new XmlArrayList(strategy);

        // Leer los objetos del archivo XML
        Clase[] arrayClase = new Clase[lista.size()];
        int contador = 0;

        for (Iterator it = lista.iterator(); it.hasNext(); ) {
            arrayClase[contador] = (Clase) it.next();
            contador++;
        }

        Clase c1 = arrayClase[0];
        Clase c2 = arrayClase[1];
        System.out.println(c1.toString());
        System.out.println(c2.toString());
    }
}
