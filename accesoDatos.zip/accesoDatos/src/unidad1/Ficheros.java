package unidad1;

import java.io.IOException;
import java.util.Properties;
import java.io.FileOutputStream;
import java.io.FileInputStream;


public class Ficheros {

	public static void main(String[] args) {
		
		guardarPropiedades();
		
		Properties[] arrayPropiedades = new Properties[2];
		arrayPropiedades = recuperarPropiedades();
		
		for(Properties p : arrayPropiedades) {
			System.out.println(p);
		}

	}
	
	public static void guardarPropiedades() {
		Properties p = new Properties();
		p.setProperty("GTA", "Rockstar Games");
		p.setProperty("LOL", "Riot Games");
		p.setProperty("Minecraft", "Mojang");
		p.setProperty("Call of Duty", "Activision");
		
		try
		(
			FileOutputStream salida = new FileOutputStream("propiedades.txt");
			FileOutputStream salidaXML = new FileOutputStream("propiedades.xml");
		) {
			p.store(salida, "fichero de tipo .txt");
			p.storeToXML(salidaXML, "fichero de tipo .xml");
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public static Properties[] recuperarPropiedades() {
		Properties pNormal = new Properties();
		Properties pXML = new Properties();
		try
		(
			FileInputStream entrada = new FileInputStream("propiedades.txt");
			FileInputStream entradaXML = new FileInputStream("propiedades.xml");
		) {
			pNormal.load(entrada);
			pXML.loadFromXML(entradaXML);
		}
		catch(IOException e){
			e.printStackTrace();
		}
		Properties[] arrayPropiedades = new Properties[2];
		arrayPropiedades[0] = pNormal;
		arrayPropiedades[1] = pXML;
 		return arrayPropiedades;
	}

}
